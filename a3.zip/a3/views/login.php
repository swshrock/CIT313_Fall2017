<?php include('elements/header.php');?>
<div class="container">
	<div class="page-header">
   <h1> the Login View </h1>
	 <?php include('elements/login_form.php');?>
   <?php echo $numbers ?>
  </div>
</div>
<?php include('elements/footer.php');?>
