<div id="navigation">
  <ul>
    <li><a href="<?php echo URL_ROOT ?>index.php">Home</a></li>
    <li><a href="<?php echo URL_ROOT ?>About/index.php">About</a></li>
    <li><a href="<?php echo URL_ROOT ?>Products/index.php">Products</a></li>
    <li><a href="<?php echo URL_ROOT ?>Services/index.php">Services</a></li>
    <li><a href="<?php echo URL_ROOT ?>Contact/index.php">Contact Us</a></li>
  </ul>
</div>
