<div id="footer">
  Copyright © Site name, 20XX
</div>


</body>
</html>
