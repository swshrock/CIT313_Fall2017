<?php

define("ABSOLUTE_PATH", "/home/swshrock/htdocs/ex1/_includes");

define("URL_ROOT",

"http://corsair.cs.iupui.edu:21981/php_includes/")


 ?>
