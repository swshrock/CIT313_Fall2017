<?php

define('ABSOLUTE_PATH', '');
define('URL_ROOT', '');