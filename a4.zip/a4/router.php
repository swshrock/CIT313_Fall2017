<?php

spl_autoload_register();

require_once 'application/load.class.php';
require_once 'application/controllers/controller.class.php';
require_once 'application/models/model.class.php';

new Controller();


 ?>
