<!DOCTYPE html>
<html>
<head>
    <Title>Fisher Price - My first model view controller</title>
</head>
<body>
  <h1>Hello from my view</h1>
  <?php

    echo "My Name is"." ".$userID." ".$firstname." ".$lastname." ".$email ." ".$role."</br>";

  ?>


</body>

</html>
